# -----------------------------------------------------------------------------
# Copyright 2001-2009 Paradigm Works, Inc., Andover MA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http:#www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ------------------------------------------------------------------------------
# File name   : SvfUtils.pm
# Title       : SystemVerilog Frameworks(TM): General Utility package
# Project     : SystemVerilog FrameWorks(TM)
# Component   : SvfUtils
# Version     : $Revision: 1.14 $
# Description : A Perl object that contains generic perl methods
#
# Notes : 
# ------------------------------------------------------------------------------

package SvfUtils;

use FindBin qw($Bin);  # Find where the bin directory is
use lib ("$Bin/../lib/external/lib/perl5");
use HTTP::Request::Common;
use LWP::UserAgent;

use Exporter;
use Cwd;
use File::Basename;
use File::Copy;       # Package used to copy files 
use File::Path;       # Package used to create/remove directories


@ISA    = ('Exporter');         # Inherit from Exporter
@EXPORT =  qw( ReadFile
	       GetDirectoryTree 
	       GetDirsFromDir 
	       GetFilesFromDir
	       GenGmDateStamp
	       OpenLockFile 
	       CloseLockFile 
	       CopyFilesToDir
	       ExpandEnvVariables
	       TeeOutput
	       AddUniqueToArray
	       SplitCommand
	       GetTempFile
	       );
use strict;

our $_debug = $ENV{'SVF_DEBUG'} ;

our $_main_process = basename($0);
$_main_process =~ s/\.pl//;

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME: ReadFile
# 
# IO_LIST:
#   $inFile               File to read.
#   $inRemoveComments     Remove comment lines?
#   $inReturnType         Array = 0; Single String = 1;
# 
# DESCRIPTION:
#   This sub is used to read in a file. This is to help provide some code re-use.
#   when all one wants is to grab the contents of a file. An option is provided to
#   strip out all of the comments in a source file. A comment is defined by the
#   "#" character. Also, another option is given to select if the file should be 
#   returned as an array of lines or a single contiguous string.
#
# RETURNS:
#  The contents of the input file in string or array format.
# ===============================================================================
sub ReadFile {

  my $inFile             = shift @_;  #File to read.
  my $inRemoveComments   = shift @_;  #Remove comment lines?
  my $inReturnType       = shift @_;  #Array = 0; Single String = 1;

  open (IN_FILE, "$inFile") or
    die "Error: unable to open file \"$inFile\" for read!\n";

  my @all_lines;
  my $single_string;

  if ($inRemoveComments) {
    #Remove all the full comment lines
    @all_lines = grep !/^\s*\#/, <IN_FILE>;
    
    #Strip the comments at the end of lines.
    foreach my $line (@all_lines) {
      $line =~ s/\#.*/\n/;
    }
  }
  else {
    @all_lines = <IN_FILE>;
  }
  
  close IN_FILE;
  
  $single_string = join ("", @all_lines);

  #Return the proper format.
  if ($inReturnType) {
    return $single_string;
  }
  else {
    return @all_lines;
  } 
} #end ReadFile()

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   GetDirectoryTree
# 
# IO_LIST:
#   $inDirList           Reference to list of directories to parse	 
#   $inRecursive         Perform the directory tree search recursively	 
#   $inExcludeList       Reference to list of name types to exclude	 
#   $inIncludeList       Reference to list of name types to include	 
#   $inVerbose           Turn verbose printing on                        
# 
# DESCRIPTION:
#    This routine will take as input a directory and will list the directories
#  in that directory. A recursive switch is provided that will provide one with
#  the full directory tree. No files are included, just directories. The "." and
#  ".." directories are excluded from the list.
#
# RETURNS:
#   A list of directory paths
#
# ===============================================================================
sub GetDirectoryTree {
  my $inDirList       = shift @_;      # Reference to list of directories to parse 
  my $inRecursive     = shift @_;      # Perform the directory tree search recursively
  my $inExcludeList   = shift @_;      # Reference to list of name types to exclude
  my $inIncludeList   = shift @_;      # Reference to list of name types to include
  my $inVerbose       = shift @_;      # Turn verbose printing on

  my @directory_list = @$inDirList;
  my @NULL;
  #--- Perform the directory search ---
  if ($inRecursive) {
    foreach my $dir (@directory_list) {
      if (-d $dir ) {
	push @directory_list, GetDirsFromDir($dir, $inExcludeList, \@NULL, $inVerbose);
      }
      else {
	print "[SvfUtils::GetDirectoryTree] WARNING: $dir is not a directory!\n" if ($inVerbose);
      }
    }
  }
  else {
    foreach my $dir (@$inDirList) {
      if (-d $dir) {
	push @directory_list, GetDirsFromDir($dir, $inExcludeList, \@NULL, $inVerbose);
      }
      else {
	print "[SvfUtils::GetDirectoryTree] WARNING: $dir is not a directory!\n" if ($inVerbose);
      }
    }
  }

    #Verify that the list of directory types desired are only included.
  if ($#$inIncludeList >= 0) {
    @directory_list = grep {MatchListToString($_, $inIncludeList)} @directory_list;
  }

  if ($inVerbose) {
    foreach my $dir (@directory_list) {
      print "[SvfUtils::GetDirectoryTree] Found: $dir\n";
    }
  }

  return @directory_list;
} #end GetDirectoryTree()
# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   GetDirsFromDir
# 
# IO_LIST:
#   $inDir            Directory to read for other directories
#
#   $inExcludeList    Reference to list of string patterns that if there is match 
#                     then the directory is not included in the return list.
#
#   $inIncludeList    Reference to list of string patterns that where at least
#                     one matches in the directory path name for the directory
#                     to be included in the return list. If empty, then all
#                     directories automatically match.

#   $inDbg            Turn debug printing on
#  
# DESCRIPTION:
#   This routine takes as input a directory. It returns a list of directories
#   that are within that directory. It only retrieves one level, i.e. It is not 
#   recursive. It removes the "." and ".." directories. 
#
# RETURNS:
#  List of Directory paths.
# ===============================================================================
sub GetDirsFromDir {

  my $inDir         = shift @_;  #directory of tests results to be parsed.
  my $inExcludeList = shift @_;  #List of directories to exclude
  my $inIncludeList = shift @_;  #List of directories to include
  my $inDbg         = shift @_;  #Turn debug commenting on
  my @dir_list;

  print "\n[SvfUtils::GetDirsFromDir]\n" if ($inDbg);

  #Is it a directory? We will no not follow symbolic links.
  if (-d $inDir and not -l $inDir) {
    opendir IN_DIR, $inDir or 
      die "Error: Unable to open directory for read: $!\n";

    my @dir_list = grep {-d and !(m-\.\z-) and !(MatchListToString($_, $inExcludeList)) }
      map { "$inDir/$_" } readdir IN_DIR;
#    my @dir_list = grep {-d and !(m-\.\z-) }
#      map { "$inDir/$_" } readdir IN_DIR;

    closedir IN_DIR;

    #Verify that the list of directory types desired are only included.
    if ($#$inIncludeList >= 0) {
	@dir_list = grep {MatchListToString($_, $inIncludeList)} @dir_list;
    }

    #Some debug printing
    if ($inDbg) {
      print "   Found the following directories:\n";
      foreach my $dir (@dir_list) {
	print "     $dir\n";
      }
    }
    return @dir_list;
  } 
  else {
    print "[SvfUtils::GetDirsFromDir] Warning: $inDir is not a directory\n";
    return;
  }
} #end GetDirsFromDir()

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   MatchListToString
# 
# IO_LIST:
#   $inString         A string to perform matching on
#   $inMatchList      Reference to a list of items to match to string
# 
# DESCRIPTION:
#   This routine takes as input a string and a list of strings. It takes each
#   item in the string list and checks to see if there is a match in the input
#   string. 
# 
# RETURNS:   
#   Boolean 0 if no match was made. Boolean 1 if a match was found
# ===============================================================================
sub MatchListToString {
  my $inString      = shift @_;
  my $inMatchList   = shift @_;
  
  foreach my $match_string (@$inMatchList) {
    if ($inString =~ m/$match_string/ and ($match_string ne '')) {
      return 1; # A match was found.
    }
  }
  
  return 0; #no match
} #end MatchListToString

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   GenGmDateStamp
# 
# IO_LIST:
#   $inFormat          The format to return the date stamp in.
#   $inOffset          The number of hours to subtract from the GM time
#   $inNoTime          Remove the time (HHMMSS) from the date stamp.
# 
# DESCRIPTION:
#  This routine is will create a time stamp using Greenwich Time. An offset
#  option is provided if one wants to get the time in a certain time zone.
#  There are also three different formats that the time can be returned in.
#  This routine is provided so that a centralized project time can be defined
#  so that date stamps are based on project time. This allows the tracking
#  of changes to the project across time zones.
#
#  Formates are controlled by setting the $inFormat option to one of the
#  following values (NOTE: The time is shown in each but it can be removed by
#  setting the $inNoTime option):
#     OPTION_1     MON_DD_YYYY-HH_MM_SS (Default)
#     OPTION_2     YYYYMMDDHHMMSS
#     OPTION_3     YYYY_MM_DD-HH_MM_SS    
#    
# RETURNS
#  The date stamp string
# ===============================================================================
sub GenGmDateStamp {

  my $inFormat = shift @_;
  my $inOffset = shift @_;
  my $inNoTime = shift @_; 

  my $time     = time();
  my $t_offset = $time - ($inOffset * 3600);

  my $this_month = ("JAN", "FEB", "MAR", "APR", 
		    "MAY", "JUN", "JUL", "AUG", 
		    "SEP", "OCT", "NOV", "DEC")[(gmtime($t_offset))[4]];
  
  my $date_stamp = sprintf("%s_%02d_%04d-%02d_%02d_%02d",
			   $this_month,
			   (gmtime($t_offset))[3],
			   ((gmtime($t_offset))[5] + 1900),
			   (gmtime($t_offset))[2],
			   (gmtime($t_offset))[1],
			   (gmtime($t_offset))[0] 
			   );

  if ($inFormat eq "OPTION_2" or
      $inFormat eq "OPTION_3") {
    $date_stamp = sprintf("%04d_%02d_%02d-%02d_%02d_%02d",
			  ((gmtime($t_offset))[5] + 1900),
			  (gmtime($t_offset))[4] + 1,
			  (gmtime($t_offset))[3],
			  (gmtime($t_offset))[2],
			  (gmtime($t_offset))[1],
			  (gmtime($t_offset))[0] 
			  );
  }
  
  $date_stamp =~ s/-.*//  if ($inNoTime);
  $date_stamp =~ s/-|_//g if ($inFormat eq "OPTION_2");

  return $date_stamp;
} #end GenGmDateStamp()

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   OpenLockFile
# 
# IO_LIST:
#   $inDir            Directory where to place lock file.
#   $inTimeout        Optional timeout to wait for lock file to become available.
#                     The number entered is in seconds. The default is 10sec. 
# 
# DESCRIPTION:
#  This routine will open a lock file. It uses the LockDir package that was 
#  taken from the Perl Cookbook. This routine will only open the file. 
#  Use the CloseLockFile routine to release the lock and delete the file. This
#  methodology was chosen because the perl flock routine does not work across
#  a network, i.e. One host machine has a lock a second machine can also gain a
#  lock.
# 
# RETURNS
#  <none>
# ===============================================================================
use LockDir;
$LockDir::Verbose = 1;
$LockDir::Check   = 60;  #If locked, try again after 1 minute
sub OpenLockFile {
  my $inDir     = shift @_;
  my $inTimeout = shift @_;
  my $timeout   = 10;

  #Set the timeout
  if ($inTimeout) {
    $timeout = $inTimeout;
  }

  #Set up the time to recheck for a lock availabilty.
  if ($timeout < 60) {
    #If less than a minute check again after the timeout.
    $LockDir::Check   = $timeout;  
  }
  elsif ($timeout < 3600) {
    #If less than an Hour check every minute.
    $LockDir::Check = 60;
  }
  else {
    #Check every Five minutes.
    $LockDir::Check = 300;
  }

  unless (nflock("$inDir/.lockfile", $timeout)) {
    print "\n ERROR: Timed out waiting for lock on $inDir\n";
    exit 1;
  }

} #end OpenLockFile()
# ===============================================================================

# ===============================================================================
# SUB NAME:   CloseLockFile
# 
# IO_LIST:
#   $inDir                   Directory where lock file is located.
# 
# DESCRIPTION:
#  This will close the lockfile that was opened with the OpenLockFile routine.
# ===============================================================================
sub CloseLockFile {
  my $inDir        = shift @_;

  nunflock("$inDir/.lockfile");

} #end CloseLockFile()

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   GetFilesFromDir
# 
# IO_LIST:
#  
#  $inDir           #Directory of where to look for files
#  $inFileTypes     #List of file types to get.
#  $outFileList     #Reference to array where to place file name list
#  $inClearList     #Delete anything that is still in $outFileList before 
#                    adding to it
#  $inDbg           #Turn debug commenting on
#
# 
# DESCRIPTION:
#   This routine takes as input a directory and a list of file extensions. It 
#   returns a list of files that are in that directory with that file extension.
#    
# RETURNS:
#  Number of files found
# ===============================================================================
sub GetFilesFromDir {

  my $inDir       = shift @_;  #directory of tests results to be parsed.
  my $inFileTypes = shift @_;  #List of file types to get.
  my $outFileList = shift @_;  #Reference to array where to place file name list
  my $inClearList = shift @_;  #Delete what is still in $outFileList before
                               #adding to it
  my $inDbg       = shift @_;  #Turn debug commenting on

  print "\nRrtUtils::GetFilesFromDir:\n" if ($inDbg);
  if ($inClearList) {
    @$outFileList = ();
  }

  if (-d $inDir) {
    opendir REGR_DIR, $inDir or 
      die "Error: Unable to open directory for read: $!\n";

    #Read the directory for all files.
    my @files = grep {-f} map { "$inDir/$_" } readdir REGR_DIR;
    closedir REGR_DIR;

    #Parse the file list for each file type.
    foreach my $file_type (@$inFileTypes) {
      print "   Retrieving files of type: @$inFileTypes" if ($inDbg);

      #Since file types can have a "." in them, which is a special search key,
      #replace this with "\.".
      my $search_type = $file_type;
      $search_type =~ s/\./\\\./;

      #Read the directory and get the appropriate files
      foreach my $file (@files) {
	(my $base, my $path, my $type) = fileparse($file, $search_type);      
	if ($type) {
	  push @$outFileList, $file;
	}
      }
    }

    #Some debug printing
    if ($inDbg) {
      print "   Found the following files:\n";
      foreach my $filename (@$outFileList) {
	print "     $filename\n";
      }
    }
    if (@$outFileList) {
      return ($#$outFileList + 1);  #Return the number of files in the array.
    }
    else {
      return 0;
    }
  }
  
  return 0;
}#end GetFilesFromDir()

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   CopyFilesToDir
# 
# IO_LIST:
#  $inDestination = shift @_;  #Destination Directory
#  $inFileListRef = shift @_;  #List of files to copy (Array Reference)
#  $inMakeDir     = shift @_;  #if set, will create the directory.
# 
# DESCRIPTION:
#  This will copy a list of files to a destination directory. The third parameter
#  is a boolean that if set will create the destination directory if it does not
#  exist. Returns 1 if all the files were copied successfully, 0 if there was 
#  an error. 
# ===============================================================================
sub CopyFilesToDir {
  my $inDestination    = shift @_;  #Destination Directory
  my $inFileListRef    = shift @_;  #List of files to copy (Array Reference)
  my $inMakeDir        = shift @_;  #if set, will create the directory.
  my $inRelativeFilter = shift @_;  #This allows one to copy the files into a
                                    #directory tree relative to the Destination
                                    #Directory. This is the string of the part 
                                    #of the filename path that is to be removed.


  #Create the destination directory if needed
  if ( !(-e $inDestination) and $inMakeDir) {
    mkpath ($inDestination, 1, 0777);
  }
  
  
  #Copy the File list
  foreach my $file (@$inFileListRef) {
    my $destination = '';
    my $file_basename = basename($file);  #Strip the filename out of the path.

    if ($inRelativeFilter) {
      #strip the trailing / from the directory path
      $inRelativeFilter =~ s-/\Z--;

      #Determine the relative path
      my $full_path = dirname($file);
      $full_path =~ s/$inRelativeFilter//;
      #strip out double "//"
      $full_path =~ s-//-/-;  
      $destination = "$inDestination/$full_path";

      #Make the directory if it does not exist
      if (!-e $destination) {
	mkpath ($destination, 1, 0777);
      }
    }
    else {
      $destination = $inDestination;
    }

     if ( ! copy ( $file, "$destination/$file_basename") ) {
       print "ERROR: Unable to copy $file to $destination. $!\n";
       return 0;  #A problem occured
     }
   }
  
  return 1; #All files copied successfully.
} #end CopyFilesToDir()

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   ExpandEnvVariables
# 
# IO_LIST:
#   $inLineToExpand   A $<variable> or a line with $<variables> in it.
# 
# DESCRIPTION:
#  This routine will take as input a path that has environment variables 
#  embedded in it. It will look for $'s and will try to expand the variable by
#  checking to see if it is defined in the environment. If it is not, then the
#  $<variable> is left alone.
# 
# RETURNS:
#  String
# ===============================================================================
sub ExpandEnvVariables {
  my $inLineToExpand = shift @_;
  my $inVerbose      = shift @_;

  my @variables = $inLineToExpand =~ m/\$(\w+)/g;
  my $new_line = $inLineToExpand;

  foreach my $variable (@variables) {
    if ($ENV{$variable}) {
      print "[ExpandEnvVariables] Expanding environment variable $variable to $ENV{$variable}\n"
	if ($inVerbose);
      $new_line =~ s/\$$variable/$ENV{$variable}/;
    }
  }
  
  return $new_line;

} #end ExpandEnvVariables()

# ==============================================================================
# ------------------------------------------------------------------------------
# ==============================================================================
# SUB NAME TeeOutput
#
# IO_LIST:
#   $inLogFile       Files to output STDOUT & STDERR to
#   $inNoStdout      Only print to files. No printing to STDOUT   
#
# DESCRIPTION:
#  This routine will create a log file that will record everthing that is 
#  printed to standard out and standard error. To print to multiple files just
#  overload the $logfile input with multiple files separated by spaces.
#
# RETURNS:
#  Process ID of child process that is handling printing
# ==============================================================================
sub TeeOutput {
    my $inLogfile  = shift @_;
    my $inNoStdout = shift @_;  #Don't print to STDOUT;

    my $options = "ua";

    if ($inNoStdout) {
      $options = $options."n";
    }

    open SAVEOUT, ">&STDOUT";
    open SAVEERR, ">&STDERR";

    my $pid = open (STDOUT,"| tctee -$options $inLogfile") or 
      die "Error: cannot route STDOUT to $inLogfile ($!)\n";
    $| = 1;
    open (STDERR,">&STDOUT") or die "Error: can't dup STDERR to STDOUT ($!)\n";

    return $pid;

} #end TeeOutput()

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   AddUniqueToArray
# 
# IO_LIST:
#   $outArray           Reference to Array to add the value to
#   $inValue            The value to add
# 
# DESCRIPTION:
#  This routine takes an array and a value to add to the array. It only adds
#  the value to the array if the value does not exist somewhere in the array
#  already. The value is added to the end of the array.
#
# RETURNS:
#  Boolean: 1 if value added to array; 0 if not added.
# ===============================================================================
sub AddUniqueToArray {
  my $outArray = shift @_;
  my $inValue  = shift @_;
  
  my $match_found = 0;

  #Check to see if the $inValue has a match on the array.
  foreach my $value (@$outArray) {
    if ($value eq $inValue) {
      $match_found = 1;
    }
  }

  #If no match was found, add the new value to the array.
  if (!$match_found) {
    push @$outArray, $inValue;
    return 1;
  }

  return 0;
} #end AddUniqueToArray()

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   SplitCommand
# 
# IO_LIST:
#   $inCommandBase      The command to append the argument list to
#   $inArgList          Reference to array of command arguments
#   $outCommands        Reference to array of output commands
# 
# DESCRIPTION:
# This routine addresses the issue of having a command line that can only take
# a limited number of arguments. This will only work with commands that one
# can call multiple times with varying the argument list. This will break the
# command up into several command calls.
# 
# ===============================================================================
sub SplitCommand {
  my $inCommandBase = shift @_;
  my $inArgList     = shift @_;
  my $outCommands   = shift @_;

  #Window Machines have a 4000 character limit.
  #tcsh shell's have a 10240 character limit.
  #bash shell's - Unable to determine (Assumed to be at least equal to tcsh shells)
  my $max_length = 10000;
  if ($^O eq "Windows_NT" or $^O eq "MSWin32") {
    $max_length = 4000;
  }
   
  #Go through the list of arguments and add the length of each one. When the max
  #is reached then split the command and add it to the output array of commands.
  my $cmd_length = length $inCommandBase;
  my $arg_length = 0;
  my $cmd = $inCommandBase;
  foreach my $item (@$inArgList) {

    if (($arg_length + $cmd_length + (length $item )) > $max_length) {
      push @$outCommands, $cmd;
      $arg_length = (length $item);
      $cmd = "$inCommandBase $item";
    }
    else {
      #The "1" accounts for spaces between arguments
      $arg_length = $arg_length + (length $item) + 1; 
      $cmd = "$cmd $item";
    }

  }
  #Add in the command that did not reach the max_length limit.
  if ($arg_length > 0) {
    push @$outCommands, $cmd;
  }

} #end SplitCommand()

# ===============================================================================
# -------------------------------------------------------------------------------
# ===============================================================================
# SUB NAME:   GetTempFile
# 
# IO_LIST:
#   none
# 
# DESCRIPTION:
#  This routine will create a system temporary file and will return the name
#  of the file. The file is automatically removed upon the programs completion.
# 
# ===============================================================================
our %_temp_name_list;
sub GetTempFile {
  use IO::File;
  use POSIX qw(tmpnam);
  use File::Spec;

  #Create a tempory file.
  my $name = '';
  my $fh   = '';
  my $tmpdir = File::Spec->tmpdir();
  
  # try new temporary filenames until we get one that didn't already exist
  if ($^O eq "Windows_NT" or $^O eq "MSWin32") {
    do { $name = "$tmpdir/" . &tmpnam() }
    until $fh = IO::File->new($name, O_RDWR|O_CREAT|O_EXCL);
  }
  else {
    do { $name = tmpnam() }
    until $fh = IO::File->new($name, O_RDWR|O_CREAT|O_EXCL);
  }
    
  # install atexit-style handler so that when we exit or die,
  # we automatically delete the temporary files. Note, we only
  # remove those temporary files that were created by the process
  # that is dieing. Therefore, only parent processes should create
  # temporary files.
   END { 
    foreach my $temp_file (keys %_temp_name_list) {
      if (-e $temp_file and ($_temp_name_list{$temp_file} == $$) ) { 
	unlink($temp_file) or warn "Couldn't unlink $temp_file : $!";
	delete $_temp_name_list{$temp_file}; 
      }
    }
  }

  close $fh;
  $_temp_name_list{$name} = $$; #Match temp file to process that created it.
  return $name;
} #end GetTempFile()


#==============================================================================
return 1 ; # return 1 so the caller's 'use' command is happy
