# -----------------------------------------------------------------------------
# Copyright 2001-2009 Paradigm Works, Inc., Andover MA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http:#www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ------------------------------------------------------------------------------
#
# File name   : LockDir.pm
# Title       : Lock Directory/file mechanism
# Project     : Gather, Validate, and Publish
# Version     : $Revision: 1.2 $
# Description : 
#   This is a locking mechanism that is provided Perl Cookbook example 7.10.
#     Perl Cookbook
#     By Tom Christiansen & Nathan Torkington 
#     ISBN 1-56592-243-3
#     First Edition, August 1998
#
# Notes       : 
#   Made a couple of tweaks to the output messages and fixed a bug where if
#   multiple lock files were created only the first one was removed in the
#   case of an interrupt.
# ------------------------------------------------------------------------------
package LockDir;
# module to provide very basic filename-level
# locks.  No fancy systems calls.  In theory,
# directory info is sync'd over NFS.  Not
# stress tested.

use strict;

use Exporter;
use vars qw(@ISA @EXPORT);
@ISA      = qw(Exporter);
@EXPORT   = qw(nflock nunflock);

use vars qw($Debug $Check $Verbose);
 $Debug   ||= 0;   # may be predefined
 $Check   ||= 5;   # may be predefined
 $Verbose ||= 0; # may be predifined

use Cwd;
use Fcntl;
use Sys::Hostname;
use File::Basename;
use File::stat;
use Carp;

my %Locked_Files = ();

# usage: nflock(FILE; NAPTILL)
sub nflock($;$) {
    my $pathname = shift;
    my $naptime  = shift || 0;
    my $lockname = name2lock($pathname);
    my $whosegot = "$lockname/owner";
    my $start    = time();
    my $missed   = 0;
    local *OWNER;

    # if locking what I've already locked, return
    if ($Locked_Files{$pathname}) {
        carp "$pathname already locked";
        return 1
    }

    if (!-w dirname($pathname)) {
        croak "can't write to directory of $pathname";
    }

    while (1) {
        last if mkdir($lockname, 0777);
        confess "can't get $lockname: $!" if $missed++ > 10
                        && !-d $lockname;
        if ($Debug or $Verbose) {{
            open(OWNER, "< $whosegot") || last; # exit "if"!
            my $lockee = <OWNER>;
            chomp($lockee);
            printf STDERR "%s $0\[$$]: lock on %s held by %s\n",
                scalar(localtime), $pathname, $lockee;
            close OWNER;
        }}
        sleep $Check;
        return if $naptime && time > $start+$naptime;
    }
    sysopen(OWNER, $whosegot, O_WRONLY|O_CREAT|O_EXCL)
                            or croak "can't create $whosegot: $!";
    printf OWNER "$0\[$$] on %s since %s\n",
            hostname(), scalar(localtime);
    close(OWNER)                
        or croak "close $whosegot: $!";
    #Store the parent PID that generated the lock
    $Locked_Files{$pathname} = $$;
    return 1;
}

# free the locked file
sub nunflock($) {
    my $pathname = shift;
    my $lockname = name2lock($pathname);
    my $whosegot = "$lockname/owner";
    unlink($whosegot);
    carp "Releasing lock on $lockname" if $Debug;
    delete $Locked_Files{$pathname};
    return rmdir($lockname);
}

# helper function
sub name2lock($) {
    my $pathname = shift;
    my $dir  = dirname($pathname);
    my $file = basename($pathname);
    $dir = getcwd() if $dir eq '.';
    my $lockname = "$dir/$file.LOCKDIR";
    return $lockname;
}

# anything forgotten?
END {
    foreach my $pathname (keys %Locked_Files) {
      #First make sure the process that is dieing is
      #the one that created the lock. This is done for
      #those processes that fork children. We don't want
      #the child to remove the lock file.
      if ($Locked_Files{$pathname} == $$) {
	my $lockname = name2lock($pathname);
        my $whosegot = "$lockname/owner";
        carp "  Releasing forgotten $lockname";
        unlink($whosegot);
        rmdir($lockname);
      }
    }
}

1;
