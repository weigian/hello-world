# -----------------------------------------------------------------------------
# Copyright 2009 Paradigm Works, Inc., Andover MA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http:#www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ------------------------------------------------------------------------------
# File name   : SvfSrtRegisterFileField.pm
# Title       : SystemVerilog Frameworks(TM):  Spec2RegTool: Register field object
# Project     : SystemVerilog FrameWorks(TM)
# Component   : Spec2RegTool
# Version     : $Revision: 1.2 $
# Description : A Perl object that contains the field parameters of registers and memories
#
# Notes : 
# ------------------------------------------------------------------------------

package SvfSrtRegisterFileField;

#### Constructor for Object
sub new {
    my ($class) = @_;
    my $self = {
        regname => undef,
	ftype => undef,
        fname => undef,
        attr => undef,
	num_bits => undef,
	reset => undef,
	first_field => undef,
	last_field => undef,
	last_field_in_regfile => undef
	};
    bless $self, $class;
    return $self;
}

#### Print method
sub print {
    my ($self) = @_;

    #### Print out the members
    printf("SvfSrtRegFileField: regname is: %s\n", $self->regname);
    printf("SvfSrtRegFileField: ftype is: %s\n", $self->ftype);
    printf("SvfSrtRegFileField: fname is: %s\n", $self->fname);
    printf("SvfSrtRegFileField: attr is: %s\n", $self->attr);
    printf("SvfSrtRegFileField: num_bits is: %s\n", $self->num_bits);
    printf("SvfSrtRegFileField: reset is: %s\n", $self->reset);
    printf("SvfSrtRegFileField: first_field is: %s\n", $self->first_field);
    printf("SvfSrtRegFileField: last_field is: %s\n", $self->last_field);
    printf("SvfSrtRegFileField: last_field_in_regfile is: %s\n", $self->last_field_in_regfile);
}


#### Accessor methods
sub regname {
    my ( $self, $regname ) = @_;
    $self->{regname} = $regname if defined($regname);
    return $self->{regname};
}

sub ftype {
    my ( $self, $ftype ) = @_;
    $self->{ftype} = $ftype if defined($ftype);
    return $self->{ftype};
}

sub fname {
    my ( $self, $fname ) = @_;
    $self->{fname} = $fname if defined($fname);
    return $self->{fname};
}

sub attr {
    my ( $self, $attr ) = @_;
    $self->{attr} = $attr if defined($attr);
    return $self->{attr};
}

sub num_bits {
    my ( $self, $num_bits ) = @_;
    $self->{num_bits} = $num_bits if defined($num_bits);
    return $self->{num_bits};
}

sub reset {
    my ( $self, $reset ) = @_;
    $self->{reset} = $reset if defined($reset);
    return $self->{reset};
}

sub first_field {
    my ( $self, $first_field ) = @_;
    $self->{first_field} = $first_field if defined($first_field);
    return $self->{first_field};
}

sub last_field {
    my ( $self, $last_field ) = @_;
    $self->{last_field} = $last_field if defined($last_field);
    return $self->{last_field};
}

sub last_field_in_regfile {
    my ( $self, $last_field_in_regfile ) = @_;
    $self->{last_field_in_regfile} = $last_field_in_regfile if defined($last_field_in_regfile);
    return $self->{last_field_in_regfile};
}


#### END Accessor methods

return 1;

