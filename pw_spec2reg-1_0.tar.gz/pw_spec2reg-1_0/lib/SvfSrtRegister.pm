# -----------------------------------------------------------------------------
# Copyright 2009 Paradigm Works, Inc., Andover MA
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http:#www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ------------------------------------------------------------------------------
# File name   : SvfSrtRegister.pm
# Title       : SystemVerilog Frameworks(TM): Spec2RegTool: Register Object
# Project     : SystemVerilog FrameWorks(TM)
# Component   : Spec2RegTool
# Version     : $Revision: 1.2 $
# Description : A Perl object that contains the top level parameters of registers and memories
#
# Notes : 
# ------------------------------------------------------------------------------

package SvfSrtRegister;

#### Constructor for Object
sub new {
    my ($class) = @_;
    my $self = {
	type => undef,
        name => undef,
	addr => undef,
        size => undef,
	start => undef
	};
    bless $self, $class;
    return $self;
}

#### Print method
sub print {
    my ($self) = @_;

    #### Print out the members
    printf("SvfSrtRegister: type is: %s\n", $self->type);
    printf("SvfSrtRegister: name is: %s\n", $self->name);
    printf("SvfSrtRegister: addr is: %s\n", $self->addr);
    printf("SvfSrtRegister: size is: %s\n", $self->size);
    printf("SvfSrtRegister: start is: %s\n", $self->start);
}


#### Accessor methods
sub type {
    my ( $self, $type ) = @_;
    $self->{type} = $type if defined($type);
    return $self->{type};
}

sub name {
    my ( $self, $name ) = @_;
    $self->{name} = $name if defined($name);
    return $self->{name};
}

sub addr {
    my ( $self, $addr ) = @_;
    $self->{addr} = $addr if defined($addr);
    return $self->{addr};
}

sub size {
    my ( $self, $size ) = @_;
    $self->{size} = $size if defined($size);
    return $self->{size};
}

sub start {
    my ( $self, $start ) = @_;
    $self->{start} = $start if defined($start);
    return $self->{start};
}


#### END Accessor methods

return 1;

