
Copyright 2001-YYYY Paradigm Works, Inc.

This Paradigm Works software is licensed under the Apache License,
Version 2.0 (the "License"); you may not use this software except in
compliance with the License. You may obtain a copy of the License at:

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
implied.

See the License for the specific language governing permissions and
limitations under the License.

Before installing and/or using the Paradigm Works Software, please
read and understand the License.  By installing and/or using this
software you are agreeing to be bound by the terms of the License.  If
you do not agree with the terms of the License, the software must be
removed, including any installation files and archival files.
